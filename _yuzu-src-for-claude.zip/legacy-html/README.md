# legacy-html

Trống cho tới khi bạn chạy `npm run split`. Sau đó 12 trang HTML gốc sẽ nằm ở đây
(`index, alpha, prime, marketplace, opportunities, points, transparency, whitelist, bridge, docs, vault, vault-yzcash`)
để tham chiếu và convert sang các route React trong `app/`.
